<?php
$_SESSION['firstname'] = "";
$_SESSION['lastname'] = "";
$_SESSION['fathersname'] = "";
$_SESSION['mothersname'] = "";
$_SESSION['gender'] = "";
$_SESSION['bloodgroup'] = "";
$_SESSION['religion'] = "";
$_SESSION['email'] = "";
$_SESSION['phone'] = "";
$_SESSION['website'] = "";
$_SESSION['country'] = "";
$_SESSION['division'] = "";
$_SESSION['rsc'] = "";
$_SESSION['postcode'] = "";
// $_SESSION['username'] = "";
$_SESSION['password'] = "";
$_SESSION['confirm_password'] = "";
$_SESSION['uploadimgerr'] = "";
$_SESSION['sq1'] = "";
$_SESSION['sq2'] = "";
$_SESSION['sq3'] = "";
$_SESSION['sq4'] = "";
$_SESSION['sq5'] = "";
$_SESSION['sq6'] = "";

//errs
$_SESSION['fnameErr'] = "";
$_SESSION['lnameErr'] = "";
$_SESSION['fathersnameErr'] = "";
$_SESSION['mothersnameErr'] = "";
$_SESSION['genderErr'] = "";
$_SESSION['bloodgroupErr'] = "";
$_SESSION['religionErr'] = "";
$_SESSION['emailErr'] = "";
$_SESSION['phoneErr'] = "";
$_SESSION['websiteErr'] = "";
$_SESSION['countryErr'] = "";
$_SESSION['divisionErr'] = "";
$_SESSION['rscErr'] = "";
$_SESSION['postcodeErr'] = "";
$_SESSION['usernameErr'] = "";
$_SESSION['passwordErr'] = "";
$_SESSION['confirm_passwordErr'] = "";
$_SESSION['passwordErr'] = "";
$_SESSION['uploadimgerr'] = "";
$_SESSION['sqErr'] = "";
$_SESSION['SSCScName'] = "";
$_SESSION['SSCGPA'] = "";
$_SESSION['SSCPY'] = "";
$_SESSION['HSCScName'] = "";
$_SESSION['HSCGPA'] = "";
$_SESSION['HSCPY'] = "";
$_SESSION['BScUnName'] = "";
$_SESSION['BScCGPA'] = "";
$_SESSION['BScPY'] = "";
$_SESSION['MScUnName'] = "";
$_SESSION['MScCGPA'] = "";

//academic infos
$_SESSION['SSCScNameErr'] = "";

$_SESSION['SSCGPAErr'] = "";

$_SESSION['SSCPYErr'] = "";

$_SESSION['HSCClgNameErr'] = "";

$_SESSION['HSCGPAErr'] = "";

$_SESSION['HSCPYErr'] = "";

$_SESSION['BScUnNameErr'] = "";

$_SESSION['BScCGPAErr'] = "";

$_SESSION['BScPYErr'] = "";

$_SESSION['MScUnNameErr'] = "";

$_SESSION['MScCGPAErr'] = "";

$_SESSION['MScPYErr'] = "";
$_SESSION['me'] = "";
?>