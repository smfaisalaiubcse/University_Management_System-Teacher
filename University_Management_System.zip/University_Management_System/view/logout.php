<form action="../controller/logout_action.php" method="post">
	<button type="submit" class="button button1" name="logout">Log Out</button>
</form>