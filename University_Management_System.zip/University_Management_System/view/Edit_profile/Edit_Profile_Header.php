<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="stylesheet" href="../styles.css">
   <title>Edit Profile</title>
</head>
<body>
    <ul class="ul-editprofile">
      <li><a href="Edit_General_Information.php">Edit General Information</a></li>
      <li><a href="Edit_Contact_Information.php">Edit Contact Information</a></li>
      <li><a href="Edit_Academic_Information.php">Edit Academic Information</a></li>
      <li><a href="Edit_Security_Information.php">Edit Security Information</a></li>
    </ul>
   <!-- <h3>Edit Profile: </h3>
   <a href="Edit_General_Information.php">Edit General Information</a> -
   <a href="Edit_Contact_Information.php">Edit Contact Information</a> -
   <a href="Edit_Academic_Information.php">Edit Academic Information</a> -
   <a href="Edit_Security_Information.php">Edit Security Information</a> -->
</body>
</html>