<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" href="../styles.css">
    </head>
<body>
    <ul>
        <li><a  href="../Dashboard.php">Dashboard</a></li>
        <li><a  href="../Courses.php">Courses</a></li>
        <li><a  href="../Profile.php">Profile</a></li>
        <li><a  href="Edit_Profile.php">Edit Profile</a></li>
        <li><a href="../change_password.php">Change Password</a></li>
    </ul>
</body>
</html>