<ul>
	<li><a class="a-navbar" href="Dashboard.php">Dashboard</a></li>
	<li><a class="a-navbar" href="Courses.php">Courses</a></li>
	<li><a class="a-navbar" href="Profile.php">Profile</a></li>
	<li><a class="a-navbar" href="./Edit_Profile/Edit_Profile.php">Edit Profile</a></li>
	<li><a class="a-navbar" href="change_password.php">Change Password</a></li>
</ul>