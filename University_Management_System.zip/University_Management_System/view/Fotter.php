<div class="footer">
	<h4>University Management System</h4>
	<h5>
		Project by: S M Faisal <br>
		Contact: 01305619071 <br>
		project submitted to: MIR MD. KAWSUR Sir
	</h5>
</div>